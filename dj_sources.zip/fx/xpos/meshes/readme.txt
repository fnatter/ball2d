Saucer From The Movie 20 Million Miles To Earth:
	This mesh was created with MAX 1.2 and saved a 3ds file.  It represents a model of the saucer as seen in the movie 20 Million Miles To Earth.  The mesh and textures were produced as artistic interpretations of copyrighted material which is allowable under present copyright law and are Copyright (C) Geo. W. Proctor 1996 U.S.A.  This mesh and textures may only be used for personal entertainment and may not be used in any commerical venture whatsoever.  Nor may the mesh and textures be distributed in any shape or form without written permission from the artist, this includes but is not limited to electronic bulletin boards and CD-ROM collections.

	Any questions pertaining to this mesh should be directed to:
Geo. W. Proctor
gwp1@airmail.net

20 Million Miles To Earth (C) Columbia Pictures.

