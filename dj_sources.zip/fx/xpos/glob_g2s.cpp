/*
This file contains global variables for each project
*/

// fifo99.h
bool KeyHandlerInstalled = false;
